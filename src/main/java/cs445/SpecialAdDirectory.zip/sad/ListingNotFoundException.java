package cs445.sad;


public class ListingNotFoundException extends Exception {

    ListingNotFoundException(String m) {
        super(m);
    }
}
