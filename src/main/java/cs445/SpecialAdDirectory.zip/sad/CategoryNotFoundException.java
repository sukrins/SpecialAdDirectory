package cs445.sad;


public class CategoryNotFoundException extends Exception {

    CategoryNotFoundException(String m) {
        super(m);
    }
}
