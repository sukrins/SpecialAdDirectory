package cs445.sad;


public class AdvertiserNotFoundException extends Exception {

    AdvertiserNotFoundException(String m) {
        super(m);
    }
}
