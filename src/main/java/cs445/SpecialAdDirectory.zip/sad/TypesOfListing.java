package cs445.sad;

public enum TypesOfListing {
	
	Regular,
	CategoryFeatured,
	HomePageFeatured
	
}
